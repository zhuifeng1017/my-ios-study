//
//  MZTouchViewController.h
//  MyTestAll
//
//  Created by  on 12-9-12.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MZTouchViewController : UIViewController

- (IBAction)doDD:(id)sender;
@end
