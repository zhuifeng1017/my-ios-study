//
//  MZNewsViewController.h
//  MyTestAll
//
//  Created by uistrong on 12-11-28.
//
//

#import <UIKit/UIKit.h>

@interface MZNewsViewController : UIViewController

@end
