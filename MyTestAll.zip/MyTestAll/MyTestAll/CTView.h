//
//  CTView.h
//  MyTestAll
//
//  Created by uistrong on 12-12-4.
//
//

#import <UIKit/UIKit.h>

@interface CTView : UIView

@end
