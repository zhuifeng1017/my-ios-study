//
//  MZLineView.h
//  MyTestAll
//
//  Created by  on 12-10-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MZLineView : UIView

@end
