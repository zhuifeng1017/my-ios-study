//
//  MZPerson.h
//  MyTestAll2
//
//  Created by uistrong on 12-12-14.
//  Copyright (c) 2012年 uistrong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MZPerson : NSObject
{
    NSString *_name;
}

@property (retain, nonatomic) NSString *name;


@end
