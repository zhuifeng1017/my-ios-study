//
//  MZAppDelegate.h
//  MyTestAll2
//
//  Created by uistrong on 12-12-14.
//  Copyright (c) 2012年 uistrong. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MZViewController;

@interface MZAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MZViewController *viewController;

@end
